const User = require("./dbschemas/User");
const Listing = require("./dbschemas/PropertyListing");
const Booking = require("./dbschemas/UserBooking");
const jsonwebtoken = require('jsonwebtoken')

var emailRegex = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
var passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9].*[0-9])(?=.*[a-z].*[a-z].*[a-z]).{8}$/;

exports.resolvers = {
  Query: {
    getAllUser: async (parent, args) => {
      return await User.find({});
    },

    getListings: async(parent,args) =>{
      return await Listing.find({});
    },

    getAdminListing: async (parent, args,context) => {
      if(context.user && context.user.type !== "admin"){
        throw new Error("Please login as Admin to view listings");
      }
      return await Listing.find({});
    },

    getUsersBooking: async (parent, args,context) => {
      if(context.user && context.user.type !== "customer"){
        throw new Error("Please login in as Customer to view Bookings");
      }
      return await Booking.find({});
    },

    getAllListingByName: async (parent, args) => {
      return await Listing.find({ listing_title: args.listing_title });
    },
    getAllListingByCity: async (parent, args) => {
      return await Listing.find({ city: args.city });
    },
    getAllListingByPostalCode: async (parent, args) => {
      return await Listing.find({ postal_code: args.postal_code });
    }
  },

  Mutation: {
    loginUser: async(parent,args) =>{
      const user = await User.findOne({
        username: args.username
      });

      if(!user)
        throw new Error("Username not found");

      if(user.password !== args.password){
        throw new Error("Invalid Password");
      }
      return jsonwebtoken.sign(
        {
          username: user.username,
          type: user.type
        },
        "somereallylongsecretkey",
        { expiresIn: '1y' }
      )
    },
    addNewListing: async (parent, args) => {
      const usernameType = await User.findOne({
        username: args.username
      }).select("type");

      if(usernameType && usernameType.type === "admin"){}
      else if(!usernameType){
        throw new Error("Username not found to add the listing");
      } 
      else {
        throw new Error(
          "Permission Denied, Only admin can list the properties"
        );
      }

      if (!emailRegex.test(args.email)) {
        throw new Error("Please check email format, should be abc@abc.com");
      }

      let listing = new Listing({
        listing_id: args.listing_id,
        listing_title: args.listing_title,
        description: args.description,
        street: args.street,
        city: args.city,
        postal_code: args.postal_code,
        price: args.price,
        email: args.email,
        username: args.username
      });
      return await listing.save();
    },

    addNewUser: async (parent, args) => {
      if (!emailRegex.test(args.email)) {
        throw new Error("Please check email format, should be abc@abc.com");
      }

      if (args.type !== "admin" && args.type !== "customer") {
        throw new Error("User can be of type admin or customer");
      }

      let user = new User({
        username: args.username,
        firstname: args.firstname,
        lastname: args.lastname,
        email: args.email,
        password: args.password,
        type: args.type
      });
      return await user.save();
    },

    addNewBooking: async (parent, args) => {
      let booking = new Booking({
        listing_id: args.listing_id,
        booking_id: args.booking_id,
        booking_date: args.booking_date,
        booking_start: args.booking_start,
        booking_end: args.booking_end,
        username: args.username
      });
      return await booking.save();
    }
  }
};
