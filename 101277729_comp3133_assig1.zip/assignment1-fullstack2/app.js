const express = require("express");
const mongoose = require("mongoose");
const TypeDefs = require("./schema");
const Resolvers = require("./resolvers");
const bodyParser = require("body-parser");
const cors = require("cors");
const { ApolloServer } = require("apollo-server-express");
const jsonwebtoken = require('jsonwebtoken')

//mongoDB Atlas Connection String
const url = "mongodb://127.0.0.1/assignment1";
const PORT = 5000;

//Connect to mongoDB Atlas
const connect = mongoose.connect(url, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

connect.then(
  db => {
    console.log("MongoDB connected successfully!");
  },
  err => {
    console.log(err);
  }
);

//Define Apollo Serverempl
const server = new ApolloServer({
  typeDefs: TypeDefs.typeDefs,
  resolvers: Resolvers.resolvers,
  context: ({ req }) => {
    if (req.headers && req.headers.authorization) {
      var auth = req.headers.authorization;
      var parts = auth.split(" ");
      var bearer = parts[0];
      var token = parts[1];
      if (bearer === "Bearer") {
        const user = getUser(token);
        if (user.error) {
          throw Error(user.msg);
        } else return { user };
      } else {
        throw Error("Authentication must use Bearer.");
      }
    } 
  }
});

const getUser = token => {
  if (token) {
    try {
      // return the user information from the token
      return jsonwebtoken.verify(token, "somereallylongsecretkey" /*process.env.JWT_SECRET*/);
    } catch (err) {
      // if there's a problem with the token, throw an error
      return { error: true, msg: "Session invalid" };
    }
  }
};

//Define Express Server
const app = express();
app.use(bodyParser.json());
app.use("*", cors());
server.applyMiddleware({ app });
app.listen({ port: PORT }, () =>
  console.log(
    `Backend server running at http://localhost:${PORT}${server.graphqlPath}`
  )
);
