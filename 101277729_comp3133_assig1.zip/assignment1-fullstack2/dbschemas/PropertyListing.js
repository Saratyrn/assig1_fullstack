const mongoose = require('mongoose');

const ListingSchema = new mongoose.Schema({
  listing_id: {
    type: String,
    required: true,
    unique: true
  },
  listing_title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  street: {
    type: String,
    required: true
  },
  city: {
    type: String,
    required: true
  },
  postal_code: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    default: 0.0,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  username: {
    type: String,
    required: true
  }
});

const Listing = mongoose.model("Listing", ListingSchema);
module.exports = Listing;